package com.itheima.pojo;

/**
 * @version v1.0
 * @ClassName: User
 * @Description: TODO(一句话描述该类的功能)
 * @Author: 黑马程序员
 */
public class User {

    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
